Morel Hunter - NoCanvasRead Bundle
====================================

CONTROLS:
WASD / Arrows = Move (tan path only)
Space = POKE / Harvest morel
L = Loupe (90s buff, reveals hidden morels within 70px)
H = Use First-Aid (+40 stamina, clears nausea)
C = Drink Thermos Coffee (+60 stamina)
B = Sell bag (Home zone only)

RUNNING:
1. Extract this zip to a simple folder (e.g., C:\morel\)
2. Double-click start.bat
3. Browser opens to http://localhost:8000/MorelGame_NoCanvasRead.html
4. Close the black window when done.

This build uses pure geometry for path detection (no canvas.getImageData), so Chrome/Edge file:// warnings are eliminated.
