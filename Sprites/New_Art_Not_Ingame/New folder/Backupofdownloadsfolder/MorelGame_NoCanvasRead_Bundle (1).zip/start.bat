@echo off
title Morel Hunter - Local Server
cd /d "%~dp0"
echo Starting local server at http://localhost:8000 ...
echo Close this window to stop the server.
python -m http.server 8000
